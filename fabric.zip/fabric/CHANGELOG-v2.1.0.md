# EpicWands Reforged v2.1.0

Minecraft 26.2

## New: Infusion system
- Added Empty Infusion Vial.
- Added Empire, Zeus, Hades and Power Infused Vials.
- Added animated wand-colored vial glare:
  - Empire: orange/gold
  - Zeus: blue/cyan
  - Hades: crimson
  - Power: purple
- Added Empire, Hades, Zeus and Power Particle Bottles.

## New: Nether particle extraction
- Empire Charged Netherrack -> Glass Bottle extraction -> Empire Particle Bottle.
- Hades Charged Bone Block -> Glass Bottle extraction -> Hades Particle Bottle.
- Zeus Charged Basalt -> Glass Bottle extraction -> Zeus Particle Bottle.
- Power Charged Nether Bricks -> Glass Bottle extraction -> Power Particle Bottle.
- After extraction, charged blocks revert to their matching vanilla base block.
- Mining the charged blocks normally does not grant a Particle Bottle.

## Nether world generation
Charged blocks only replace their matching vanilla block type.
- Empire / Netherrack: 40 placement attempts per chunk.
- Zeus / Basalt: 40 placement attempts per chunk.
- Hades / Bone Block: 1024 placement attempts per chunk.
- Power / Nether Bricks: 128 placement attempts per chunk.
- Uses exact single-block replacement features so unrelated Nether blocks are not replaced.

## New: Infusion Table
- Added placeable Infusion Table block with custom top and side textures.
- Added two-slot interface:
  - Top: Particle Bottle.
  - Bottom: Empty Infusion Vial.
- Infusion takes approximately 4 seconds / 80 ticks.
- Output is determined by the Particle Bottle type.
- Added vertical pouring-style progress indicator that fills downward into the vial.
- Progress color matches Empire, Zeus, Hades or Power.

## Crafting
### Infusion Vial x2
- Glass Pane / Amethyst Shard / Glass Pane
- Empty / Glass Bottle / Empty
- Empty / Iron Nugget / Empty

### Infusion Table x1
- Obsidian / Lapis Lazuli / Obsidian
- Dark Oak Planks / Enchanting Table / Dark Oak Planks
- Obsidian / Diamond / Obsidian

## Loader parity
- Fabric and Forge release builds now include the Infusion system.
- Forge-specific registry, client-screen and EventBus compatibility fixes for Forge 65.1.0 / Minecraft 26.2.
