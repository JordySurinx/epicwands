package com.epicwands.reforged.infusion;

import com.epicwands.reforged.armor.InfusionTableFabric;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.gui.screens.MenuScreens;

public final class InfusionTableClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        MenuScreens.register(InfusionTableFabric.MENU_TYPE, new InfusionTableScreenFactory());
        System.out.println("[EpicWands] Infusion Table screen registered with concrete 26.2 factory");
    }
}
