package com.epicwands.reforged.infusion;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

public final class InfusionTableScreen extends AbstractContainerScreen<InfusionTableMenu> {
    private long pourStartMs = -1L;
    private String activeBottle = "";

    public InfusionTableScreen(InfusionTableMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        System.out.println("[EpicWands] Infusion Table client screen constructed (visible panel + 4s pouring indicator)");
    }

    private static String desc(ItemStack stack) {
        try {
            if (stack == null || stack.isEmpty()) return "";
            return stack.getItem().getDescriptionId();
        } catch (Throwable t) {
            return "";
        }
    }

    private static boolean isParticleBottle(String d) {
        return d.equals("item.epicwands.empire_particle_bottle")
                || d.equals("item.epicwands.zeus_particle_bottle")
                || d.equals("item.epicwands.hades_particle_bottle")
                || d.equals("item.epicwands.power_particle_bottle");
    }

    private static int pourColor(String d) {
        if (d.equals("item.epicwands.empire_particle_bottle")) return 0xFFFF9B32;
        if (d.equals("item.epicwands.zeus_particle_bottle"))   return 0xFF39CFFF;
        if (d.equals("item.epicwands.hades_particle_bottle")) return 0xFFCC2948;
        return 0xFFB849F5;
    }

    private static int brightColor(String d) {
        if (d.equals("item.epicwands.empire_particle_bottle")) return 0xFFFFD98A;
        if (d.equals("item.epicwands.zeus_particle_bottle"))   return 0xFFD5F7FF;
        if (d.equals("item.epicwands.hades_particle_bottle")) return 0xFFFF94A6;
        return 0xFFE9C3FF;
    }

    private float pouringProgress() {
        try {
            Slot topSlot = this.menu.getSlot(0);
            Slot bottomSlot = this.menu.getSlot(1);
            String top = desc(topSlot.getItem());
            String bottom = desc(bottomSlot.getItem());

            boolean active = isParticleBottle(top) && bottom.equals("item.epicwands.infusion_vial");
            if (!active) {
                pourStartMs = -1L;
                activeBottle = "";
                return 0.0F;
            }

            long now = System.currentTimeMillis();
            if (pourStartMs < 0L || !top.equals(activeBottle)) {
                pourStartMs = now;
                activeBottle = top;
            }

            float p = (now - pourStartMs) / 4000.0F;
            return Math.max(0.0F, Math.min(1.0F, p));
        } catch (Throwable t) {
            pourStartMs = -1L;
            activeBottle = "";
            return 0.0F;
        }
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        try {
            super.extractBackground(graphics, mouseX, mouseY, delta);

            final int x = this.leftPos;
            final int y = this.topPos;

            // Main panel.
            graphics.fill(x, y, x + this.imageWidth, y + this.imageHeight, 0xF21A1422);
            graphics.outline(x, y, this.imageWidth, this.imageHeight, 0xFF8D4FC7);
            graphics.outline(x + 2, y + 2, this.imageWidth - 4, this.imageHeight - 4, 0xFF3D2854);

            // Infusion chamber.
            graphics.fill(x + 62, y + 18, x + 114, y + 78, 0xFF24192F);
            graphics.outline(x + 62, y + 18, 52, 60, 0xFF6F3D9A);

            // Top Particle Bottle slot.
            graphics.fill(x + 79, y + 26, x + 98, y + 45, 0xFF0F0C13);
            graphics.outline(x + 79, y + 26, 19, 19, 0xFFB57AE3);

            // Bottom vial slot.
            graphics.fill(x + 79, y + 52, x + 98, y + 71, 0xFF0F0C13);
            graphics.outline(x + 79, y + 52, 19, 19, 0xFFB57AE3);

            // Small static connection between bottle and vial.
            graphics.fill(x + 87, y + 45, x + 90, y + 52, 0xFF6B4D86);
            graphics.fill(x + 84, y + 49, x + 93, y + 52, 0xFF6B4D86);

            // Furnace-style vertical progress tube, flowing down towards the vial.
            final int barX = x + 103;
            final int barY = y + 27;
            final int barW = 7;
            final int barH = 43;
            graphics.fill(barX, barY, barX + barW, barY + barH, 0xFF0D0A11);
            graphics.outline(barX, barY, barW, barH, 0xFF684882);

            float progress = pouringProgress();
            if (progress > 0.0F) {
                int liquid = pourColor(activeBottle);
                int bright = brightColor(activeBottle);
                int filled = Math.max(1, Math.min(barH - 2, Math.round((barH - 2) * progress)));
                int fillTop = barY + 1;
                int fillBottom = fillTop + filled;

                // Main liquid/energy column fills DOWNWARD over ~4 seconds.
                graphics.fill(barX + 1, fillTop, barX + barW - 1, fillBottom, liquid);
                graphics.fill(barX + 2, fillTop, barX + 4, fillBottom, bright);

                // Bright leading edge/drip.
                graphics.fill(barX, fillBottom - 1, barX + barW, fillBottom + 1, bright);

                // Once the pour gets near the vial, route it left into the vial mouth.
                if (progress > 0.72F) {
                    int routeStart = barX - 1;
                    int routeEnd = x + 96;
                    graphics.fill(routeEnd, y + 66, routeStart, y + 69, liquid);
                    graphics.fill(x + 94, y + 64, x + 98, y + 71, bright);
                }

                // Vial frame lights up near completion.
                if (progress > 0.88F) {
                    graphics.outline(x + 78, y + 51, 21, 21, bright);
                }
            }

            // Player inventory area.
            graphics.fill(x + 5, y + 80, x + 171, y + 163, 0xFF15111B);
            graphics.outline(x + 5, y + 80, 166, 83, 0xFF4C365E);

            for (int row = 0; row < 3; row++) {
                for (int col = 0; col < 9; col++) {
                    int sx = x + 7 + col * 18;
                    int sy = y + 83 + row * 18;
                    graphics.fill(sx, sy, sx + 18, sy + 18, 0xFF0E0B12);
                    graphics.outline(sx, sy, 18, 18, 0xFF33273D);
                }
            }
            for (int col = 0; col < 9; col++) {
                int sx = x + 7 + col * 18;
                int sy = y + 141;
                graphics.fill(sx, sy, sx + 18, sy + 18, 0xFF0E0B12);
                graphics.outline(sx, sy, 18, 18, 0xFF463254);
            }
        } catch (Throwable t) {
            System.err.println("[EpicWands] Infusion Table SCREEN RENDER ROOT CAUSE: " + t);
            t.printStackTrace();
            throw t;
        }
    }
}
