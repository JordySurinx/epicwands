package com.epicwands.reforged.infusion;

import com.epicwands.reforged.armor.InfusionTableFabric;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.lang.reflect.Method;

public final class InfusionTableMenu extends AbstractContainerMenu {
    public static final int PROCESS_TICKS = 80;
    private static final int TABLE_SLOTS = 2;
    private static final int PLAYER_START = TABLE_SLOTS;
    private static final int PLAYER_END = PLAYER_START + Inventory.INVENTORY_SIZE;

    private final Container container;
    private final boolean serverSide;
    private int progress;

    // Client constructor used by MenuType.
    public InfusionTableMenu(int containerId, Inventory inventory) {
        this(containerId, inventory, createClientContainer(), false);
    }

    private static Container createClientContainer() {
        try {
            System.out.println("[EpicWands] Infusion Table CLIENT menu supplier entered");
            Container c = new SimpleContainer(TABLE_SLOTS);
            System.out.println("[EpicWands] Infusion Table CLIENT SimpleContainer created");
            return c;
        } catch (Throwable t) {
            System.err.println("[EpicWands] Infusion Table CLIENT MENU ROOT CAUSE: " + t);
            t.printStackTrace();
            throw t;
        }
    }

    public InfusionTableMenu(int containerId, Inventory inventory, Container container, boolean serverSide) {
        super(InfusionTableFabric.MENU_TYPE, containerId);
        System.out.println("[EpicWands] Infusion Table menu: super constructor OK (server=" + serverSide + ")");
        checkContainerSize(container, TABLE_SLOTS);
        System.out.println("[EpicWands] Infusion Table menu: container size OK");
        this.container = container;
        this.serverSide = serverSide;
        this.progress = 0;
        System.out.println("[EpicWands] Infusion Table menu: container lifecycle hook skipped (26.2-safe)");

        // Exactly two machine slots, vertically aligned.
        this.addSlot(new ParticleBottleSlot(container, 0, 80, 27));
        System.out.println("[EpicWands] Infusion Table menu: particle slot OK");
        this.addSlot(new EmptyVialSlot(container, 1, 80, 53));
        System.out.println("[EpicWands] Infusion Table menu: vial slot OK");

        // Player inventory + hotbar, added manually for Minecraft 26.2.
        // Avoid AbstractContainerMenu.addStandardInventorySlots(), whose runtime signature changed.
        Container playerInventory = (Container) (Object) inventory;
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                int index = col + row * 9 + 9;
                this.addSlot(new Slot(playerInventory, index, 8 + col * 18, 84 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            this.addSlot(new Slot(playerInventory, col, 8 + col * 18, 142));
        }
        System.out.println("[EpicWands] Infusion Table menu: 36 player slots added manually (26.2-safe)");
    }

    @Override
    public void broadcastChanges() {
        if (serverSide) {
            String output = outputForCurrentRecipe();
            if (output != null) {
                progress++;
                if (progress >= PROCESS_TICKS) {
                    finishInfusion(output);
                    progress = 0;
                }
            } else {
                progress = 0;
            }
        }
        super.broadcastChanges();
    }

    private String outputForCurrentRecipe() {
        ItemStack particle = container.getItem(0);
        ItemStack vial = container.getItem(1);
        if (particle == null || vial == null || particle.isEmpty() || vial.isEmpty()) return null;
        if (!"item.epicwands.infusion_vial".equals(description(vial))) return null;

        return switch (description(particle)) {
            case "item.epicwands.empire_particle_bottle" -> "item.epicwands.empire_infused_vial";
            case "item.epicwands.zeus_particle_bottle" -> "item.epicwands.zeus_infused_vial";
            case "item.epicwands.hades_particle_bottle" -> "item.epicwands.hades_infused_vial";
            case "item.epicwands.power_particle_bottle" -> "item.epicwands.power_infused_vial";
            default -> null;
        };
    }

    private void finishInfusion(String outputDescription) {
        Item output = findRegisteredItem(outputDescription);
        if (output == null) {
            System.err.println("[EpicWands] Infusion Table could not resolve output " + outputDescription);
            return;
        }

        // Slots are limited to one item. Consume particle + empty vial, then put result in bottom slot.
        container.setItem(0, ItemStack.EMPTY);
        container.setItem(1, output.getDefaultInstance());
        container.setChanged();
        System.out.println("[EpicWands] Infusion Table completed: " + outputDescription);
    }

    private static String description(ItemStack stack) {
        try {
            return stack.getItem().getDescriptionId();
        } catch (Throwable t) {
            return "";
        }
    }

    private static Item findRegisteredItem(String descriptionId) {
        try {
            Object registry = Class.forName("net.minecraft.core.registries.BuiltInRegistries").getField("ITEM").get(null);
            if (registry instanceof Iterable<?> iterable) {
                for (Object value : iterable) {
                    if (value instanceof Item item && descriptionId.equals(item.getDescriptionId())) {
                        return item;
                    }
                }
            }
        } catch (Throwable t) {
            System.err.println("[EpicWands] Item lookup failed: " + t);
        }
        return null;
    }

    private static boolean isParticleBottle(ItemStack stack) {
        String d = description(stack);
        return d.equals("item.epicwands.empire_particle_bottle")
                || d.equals("item.epicwands.zeus_particle_bottle")
                || d.equals("item.epicwands.hades_particle_bottle")
                || d.equals("item.epicwands.power_particle_bottle");
    }

    private static boolean isEmptyVial(ItemStack stack) {
        return "item.epicwands.infusion_vial".equals(description(stack));
    }

    @Override
    public ItemStack quickMoveStack(Player player, int slotIndex) {
        // Keep the first functional build conservative: normal clicking/dragging works,
        // while shift-clicking is intentionally disabled to avoid accidental recipe mixing.
        return ItemStack.EMPTY;
    }

    @Override
    public boolean stillValid(Player player) {
        return true;
    }

    @Override
    public void removed(Player player) {
        super.removed(player);
        if (!serverSide) return;

        // Crafting-station behavior: unfinished ingredients/results go back to the player.
        for (int i = 0; i < TABLE_SLOTS; i++) {
            ItemStack stack = container.getItem(i);
            if (stack == null || stack.isEmpty()) continue;
            container.setItem(i, ItemStack.EMPTY);
            giveBack(player, stack);
        }
    }

    private static void giveBack(Player player, ItemStack stack) {
        try {
            Object inv = player.getInventory();
            for (Method m : inv.getClass().getMethods()) {
                if (!m.getName().equals("add") || m.getParameterCount() != 1) continue;
                if (!m.getParameterTypes()[0].isAssignableFrom(ItemStack.class) && !m.getParameterTypes()[0].isInstance(stack)) continue;
                Object r = m.invoke(inv, stack);
                if (!(r instanceof Boolean b) || b) return;
            }
            // If add() was unavailable/full, try dropping the stack.
            for (Method m : player.getClass().getMethods()) {
                if (!m.getName().equals("drop") || m.getParameterCount() < 1) continue;
                Class<?>[] p = m.getParameterTypes();
                if (p.length == 2 && p[0].isAssignableFrom(ItemStack.class) && p[1] == boolean.class) {
                    m.invoke(player, stack, false);
                    return;
                }
            }
        } catch (Throwable t) {
            System.err.println("[EpicWands] Failed returning Infusion Table item: " + t);
        }
    }

    private static final class ParticleBottleSlot extends Slot {
        ParticleBottleSlot(Container container, int index, int x, int y) {
            super(container, index, x, y);
        }
        @Override public boolean mayPlace(ItemStack stack) { return isParticleBottle(stack); }
        @Override public int getMaxStackSize() { return 1; }
    }

    private static final class EmptyVialSlot extends Slot {
        EmptyVialSlot(Container container, int index, int x, int y) {
            super(container, index, x, y);
        }
        @Override public boolean mayPlace(ItemStack stack) { return isEmptyVial(stack); }
        @Override public int getMaxStackSize() { return 1; }
    }
}
