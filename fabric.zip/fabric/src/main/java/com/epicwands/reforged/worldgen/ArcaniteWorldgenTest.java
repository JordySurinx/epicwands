package com.epicwands.reforged.worldgen;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.placement.PlacedFeature;

public final class ArcaniteWorldgenTest implements ModInitializer {
    public static final ResourceKey<PlacedFeature> ARCANITE_ORE = ResourceKey.create(
        Registries.PLACED_FEATURE,
        Identifier.fromNamespaceAndPath("epicwands", "arcanite_ore")
    );

    public static final ResourceKey<PlacedFeature> VOID_CRYSTAL_ORE = ResourceKey.create(
        Registries.PLACED_FEATURE,
        Identifier.fromNamespaceAndPath("epicwands", "void_crystal_ore")
    );

    @Override
    public void onInitialize() {
        BiomeModifications.addFeature(
            BiomeSelectors.foundInOverworld(),
            GenerationStep.Decoration.UNDERGROUND_ORES,
            ARCANITE_ORE
        );

        BiomeModifications.addFeature(
            BiomeSelectors.foundInTheEnd(),
            GenerationStep.Decoration.UNDERGROUND_ORES,
            VOID_CRYSTAL_ORE
        );
    }
}
