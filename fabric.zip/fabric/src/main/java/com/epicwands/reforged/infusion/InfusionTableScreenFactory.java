package com.epicwands.reforged.infusion;

import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;

public final class InfusionTableScreenFactory implements MenuScreens.ScreenConstructor {
    @Override
    public Screen create(AbstractContainerMenu menu, Inventory inventory, Component title) {
        System.out.println("[EpicWands] Infusion Table concrete screen factory called");
        return new InfusionTableScreen((InfusionTableMenu) menu, inventory, title);
    }
}
