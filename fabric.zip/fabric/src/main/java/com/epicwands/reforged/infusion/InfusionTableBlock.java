package com.epicwands.reforged.infusion;

import com.epicwands.reforged.armor.InfusionTableFabric;
import me.jordy.epicwands.ResultCompat;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;

public final class InfusionTableBlock extends Block implements MenuProvider {
    public InfusionTableBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    private InteractionResult open(Level level, Player player) {
        if (!level.isClientSide()) {
            try {
                for (Method m : player.getClass().getMethods()) {
                    if (!m.getName().equals("openMenu") || m.getParameterCount() != 1) continue;
                    Class<?> p = m.getParameterTypes()[0];
                    if (p.isAssignableFrom(this.getClass()) || p.isInstance(this) || p.getName().equals("net.minecraft.world.MenuProvider")) {
                        m.invoke(player, this);
                        break;
                    }
                }
            } catch (InvocationTargetException ite) {
                Throwable cause = ite.getCause() != null ? ite.getCause() : ite;
                System.err.println("[EpicWands] Failed to open Infusion Table menu - ROOT CAUSE: " + cause);
                cause.printStackTrace();
            } catch (Throwable t) {
                System.err.println("[EpicWands] Failed to open Infusion Table menu: " + t);
                t.printStackTrace();
            }
        }
        return ResultCompat.success();
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return open(level, player);
    }

    @Override
    protected InteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return open(level, player);
    }

    @Override
    public Component getDisplayName() {
        return InfusionTableFabric.tableTitle();
    }

    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory inventory, Player player) {
        System.out.println("[EpicWands] Infusion Table createMenu entered, id=" + containerId);
        try {
            net.minecraft.world.SimpleContainer container = new net.minecraft.world.SimpleContainer(2);
            System.out.println("[EpicWands] Infusion Table SimpleContainer created");
            AbstractContainerMenu menu = new InfusionTableMenu(containerId, inventory, container, true);
            System.out.println("[EpicWands] Infusion Table server menu constructed");
            return menu;
        } catch (Throwable t) {
            System.err.println("[EpicWands] Infusion Table createMenu FAILED - ROOT CAUSE: " + t);
            t.printStackTrace();
            throw t;
        }
    }
}
