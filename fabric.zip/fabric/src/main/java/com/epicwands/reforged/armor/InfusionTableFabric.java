package com.epicwands.reforged.armor;

import com.epicwands.reforged.infusion.InfusionTableBlock;
import com.epicwands.reforged.infusion.InfusionTableMenu;
import net.fabricmc.api.ModInitializer;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.flag.FeatureFlagSet;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;

import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;

public final class InfusionTableFabric implements ModInitializer {
    public static MenuType<InfusionTableMenu> MENU_TYPE;
    public static Block TABLE_BLOCK;

    @Override
    public void onInitialize() {
        System.out.println("[EpicWands] registering functional Infusion Table...");

        try {
            Identifier id = Identifier.fromNamespaceAndPath("epicwands", "infusion_table");
            @SuppressWarnings({"rawtypes", "unchecked"})
            ResourceKey menuKey = ResourceKey.create(Registries.MENU, id);

            FeatureFlagSet flags = findRuntimeFeatureFlagSet();
            System.out.println("[EpicWands] Infusion Table runtime feature flags resolved");

            MenuType.MenuSupplier<InfusionTableMenu> supplier = InfusionTableMenu::new;
            MENU_TYPE = createMenuTypeRuntime(supplier, flags);
            System.out.println("[EpicWands] Infusion Table menu object created");

            // Use the same ResourceKey-based reflective registration route already proven by ArcaneArmorFabric.
            ArcaneArmorFabric.invoke(BuiltInRegistries.MENU, menuKey, MENU_TYPE);
            System.out.println("[EpicWands] Infusion Table menu registered");

            ResourceKey<Block> key = ArcaneArmorCommon.blockKey("infusion_table");
            BlockBehaviour.Properties props = BlockBehaviour.Properties.ofFullCopy(Blocks.ENCHANTING_TABLE).setId(key);
            TABLE_BLOCK = new InfusionTableBlock(props);
            System.out.println("[EpicWands] Infusion Table block object created");

            ArcaneArmorFabric.rb(key, TABLE_BLOCK);
            ArcaneArmorFabric.bi("infusion_table", TABLE_BLOCK);
            System.out.println("[EpicWands] functional Infusion Table registered (80 tick / 4 second process)");
        } catch (Throwable t) {
            System.err.println("[EpicWands] Infusion Table registration FAILED: " + t);
            t.printStackTrace();
            throw new RuntimeException("EpicWands Infusion Table registration failed", t);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static MenuType<InfusionTableMenu> createMenuTypeRuntime(MenuType.MenuSupplier<InfusionTableMenu> supplier, FeatureFlagSet flags) throws Exception {
        for (Constructor<?> ctor : MenuType.class.getDeclaredConstructors()) {
            Class<?>[] p = ctor.getParameterTypes();
            if (p.length != 2) continue;
            if (!p[0].isInstance(supplier) && !p[0].isAssignableFrom(MenuType.MenuSupplier.class)) continue;
            if (!p[1].isInstance(flags) && !p[1].isAssignableFrom(flags.getClass())) continue;
            ctor.setAccessible(true);
            return (MenuType<InfusionTableMenu>) ctor.newInstance(supplier, flags);
        }
        throw new NoSuchMethodException("No compatible MenuType(MenuSupplier, FeatureFlagSet) constructor found at runtime");
    }

    private static FeatureFlagSet findRuntimeFeatureFlagSet() throws Exception {
        Class<?> setClass = Class.forName("net.minecraft.world.flag.FeatureFlagSet");
        String[] holders = {
            "net.minecraft.world.flag.FeatureFlags",
            "net.minecraft.world.flag.FeatureFlagSet"
        };

        // Prefer well-known/default-looking static FeatureFlagSet fields without linking to a specific mapping name.
        for (String holderName : holders) {
            Class<?> holder;
            try {
                holder = Class.forName(holderName);
            } catch (Throwable ignored) {
                continue;
            }
            Field[] fields = holder.getDeclaredFields();
            for (String wanted : new String[]{"DEFAULT_FLAGS", "VANILLA_SET", "VANILLA_FLAGS", "DEFAULT_SET"}) {
                for (Field f : fields) {
                    if (!f.getName().equals(wanted)) continue;
                    if (!Modifier.isStatic(f.getModifiers())) continue;
                    if (!setClass.isAssignableFrom(f.getType())) continue;
                    f.setAccessible(true);
                    Object value = f.get(null);
                    if (value != null) return (FeatureFlagSet) value;
                }
            }
            for (Field f : fields) {
                if (!Modifier.isStatic(f.getModifiers())) continue;
                if (!setClass.isAssignableFrom(f.getType())) continue;
                f.setAccessible(true);
                Object value = f.get(null);
                if (value != null) return (FeatureFlagSet) value;
            }
        }

        // Fallback: look for a zero-argument static factory returning FeatureFlagSet.
        for (Method m : setClass.getDeclaredMethods()) {
            if (!Modifier.isStatic(m.getModifiers())) continue;
            if (!setClass.isAssignableFrom(m.getReturnType())) continue;
            if (m.getParameterCount() != 0) continue;
            m.setAccessible(true);
            Object value = m.invoke(null);
            if (value != null) return (FeatureFlagSet) value;
        }

        throw new IllegalStateException("Unable to resolve Minecraft's runtime FeatureFlagSet");
    }

    public static Component tableTitle() {
        try {
            Class<?> c = Class.forName("net.minecraft.network.chat.Component");
            for (Method m : c.getMethods()) {
                if (!m.getName().equals("translatable") || !java.lang.reflect.Modifier.isStatic(m.getModifiers())) continue;
                Class<?>[] p = m.getParameterTypes();
                if (p.length == 1 && p[0] == String.class) {
                    return (Component)m.invoke(null, "block.epicwands.infusion_table");
                }
                if (p.length == 2 && p[0] == String.class && p[1].isArray()) {
                    return (Component)m.invoke(null, "block.epicwands.infusion_table", new Object[0]);
                }
            }
        } catch (Throwable ignored) {}
        throw new IllegalStateException("Unable to create Infusion Table title component");
    }
}
